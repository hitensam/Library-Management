from setuptools import setup

setup(
    name="Library-Management",
    version="",
    packages=[""],
    url="",
    license="",
    author="andrewschell",
    author_email="",
    description="",
)
